public final class Colorpicker {
    static final String[] color = {"#color1", "#color2", "#color_dandebedande", "#color_boshghabparande", "..."};


    //This class is being used as a namespace for colors, nothing more
}