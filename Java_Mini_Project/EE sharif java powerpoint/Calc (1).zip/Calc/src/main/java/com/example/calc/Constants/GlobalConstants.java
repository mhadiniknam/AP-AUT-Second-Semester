package com.example.calc.Constants;

public class GlobalConstants {

    public static int imageHeight = 67;
    public  static   int sceneHeight=325;
    public  static   int sceneWidth =275;
    public  static int imageWidth =60;
}