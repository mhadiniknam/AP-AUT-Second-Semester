package com.example.calc.logic;

public enum Operator {
    PLUS, MINUS, DIVIDE, MULTIPLY, UNKNOWN
}
